(function(){
    cargarPersonal();


 function cargarPersonal() {
       $.ajax({
          url: "./php/personal_listar.php",
          type: 'GET',
          dataType: 'json',
          success: function(data) {
              let fila = "";
              let i = 1;
             data.forEach(emp => {
                 fila += `
                     <tr>
                         <td>${i++}</td>
                         <td>${emp.ced_personal}  ${emp.nom_personal}</td>
                         <td>${emp.car_personal}</td>
                         <td class="d-flex justify-content-end gap-2">
                              <button class="btn btn-info btn-sm btn_edita" data-id="${emp.ced_personal}">Editar</button>
                              <button class="btn btn-danger btn-sm btn_elimina" data-id="${emp.ced_personal}">Eliminar</button> 
                         </td>
                     </tr>
                   `;
                });
              $("#tablaPersonal").html(fila);
            },
         error: function(xhr, status, error) {
              console.log(error);
              alert("Error al cargar empleados");
            }
        });
    }
  



  $(".btn_nuevo").click(function(){
  $(".formPersonal").removeClass("d-none");
  $(".tablepersonal").addClass("d-none");
  });


  $(".btn_guarda").click(function(e){
     e.preventDefault();
     let cedula = $("#cedula").val();
     let apellido = $("#apellido").val();
     let nombre = $("#nombre").val();
     let cargo = $("#cargo").val();


      $.ajax({
          type:"POST",
          url:"./php/guardar.php",
          data:{cedula,apellido,nombre,cargo},
          dataType:"Json"




        }).done(function(res){
           alert(res.message);
        
        
        })



    })

 $(document).on("click", ".btn_edita", function(e){
      let codigo= e.currentTarget.dataset.id
     $.ajax({
          type:`GET`,
          url:`./php/consulta.php`,
          data:{codigo},
          dataType:"json"   
        }).done(function(res){
              $(".formPersonal").removeClass("d-none");
              $(".tablepersonal").addClass("d-none");
         
             $("#cedula").val(res.ced_personal);
             $("#apellido").val(res.apellido);
             $("#nombre").val(res.nombre);
             $("#cargo").val(res.cargo);
          
        
       cargarPersonal()      
            })
    
    
    })



$(document).on("click", ".btn_elimina", function(e){
      let codigo= e.currentTarget.dataset.id
     $.ajax({
          type:`GET`,
          url:`./php/elimina.php`,
          data:{codigo},
          dataType:"json"   
        }).done(function(res){
            alert(res.message);
            cargarPersonal()
        })
     })


})();