<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$host = "localhost";
$db   = "contabilidad";
$user = "root";
$pass = "";
try {
    $pdo = new PDO("mysql:
host=$host;
dbname=$db;
charset=utf8", 
$user, $pass
);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die(" Error de conexión: " . $e->getMessage());
}

$consulta=$pdo->query("SELECT ced_personal, ape_personal, nom_personal, car_personal FROM tbl_personal");

// $sql = "SELECT ced_personal, ape_personal, nom_personal, car_personal FROM tbl_personal";
 //   $stmt = $pdo->prepare($sql);
 //   $stmt->execute();
    $personal = $consulta->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($personal);
?>