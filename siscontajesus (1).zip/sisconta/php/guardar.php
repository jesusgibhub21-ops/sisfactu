<?php
$host = "localhost";
$db   = "contabilidad";
$user = "root";
$pass = "";
try {
    $pdo = new PDO("mysql:
host=$host;
dbname=$db;
charset=utf8", 
$user, $pass
);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die(" Error de conexión: " . $e->getMessage());
}


$ced= $_POST['cedula'];
$nom= $_POST['nombre'];
$ape= $_POST['apellido'];
$car= $_POST['cargo'];


$insertar = $pdo->query("
     INSERT INTO tbl_personal
     (ced_personal, nom_personal, ape_personal, car_personal) 
     VALUES ('$ced', '$nom', '$ape', '$car')
     ON DUPLICATE KEY UPDATE
     ced_personal = '$ced',
     nom_personal = '$nom',
     ape_personal = '$ape',
     car_personal = '$car'
     
     ");


if($insertar) {
    echo json_encode([
        "success" => true,
        "message" => "Personal guardado correctamente" 
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al guardar el personal"
    ]);
}
?>